/*
 Navicat Premium Data Transfer

 Source Server         : s
 Source Server Type    : MySQL
 Source Server Version : 50725
 Source Host           : localhost:3306
 Source Schema         : test

 Target Server Type    : MySQL
 Target Server Version : 50725
 File Encoding         : 65001

 Date: 06/04/2020 17:06:38
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for member
-- ----------------------------
DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  UNIQUE KEY `users_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of member
-- ----------------------------
BEGIN;
INSERT INTO `member` VALUES (1, 'admin', '18a960a3a0b3554b314ebe77fe545c85');
COMMIT;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) DEFAULT NULL,
  `money` int(255) DEFAULT NULL,
  UNIQUE KEY `users_id_uindex` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of users
-- ----------------------------
BEGIN;
INSERT INTO `users` VALUES (1, 'admin', 1000000);
INSERT INTO `users` VALUES (2, 'tom', 30);
INSERT INTO `users` VALUES (3, 'jerry', 50);
INSERT INTO `users` VALUES (4, 'tomcat', 60);
INSERT INTO `users` VALUES (5, 'bob', 40);
INSERT INTO `users` VALUES (6, 'Adele', 430);
INSERT INTO `users` VALUES (7, 'alex', 65535);
INSERT INTO `users` VALUES (8, 'Mike', 1337);
INSERT INTO `users` VALUES (9, 'guest', 1000);
COMMIT;

SET FOREIGN_KEY_CHECKS = 1;
