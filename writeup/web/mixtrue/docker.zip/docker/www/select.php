<?php
include "profile.php";
$search = $_POST['search'];

if($_SESSION['admin']==1){
    print <<<EOT
<form class="form" action="select.php" method="post">
    <div class="form-group">
        <label for="disabledTextInput">You can search anything here!!</label></br>
        <input type="text" name="search" id="fromgo" class="form-control">
    </div>
    </div>
    <div class="form-group">
        <input type="submit" name="submit" class="btn btn-info btn-md" value="submit">
    </div>
</form>
EOT;
}
else{
    print <<<EOT
  <div class="container"> 
  	<div class="row"  >  	      
  			<div class="col-md-10 col-md-offset-4"> 			
    			<div class="input-group" display：block;margin：0 auto;>   						  	     				 
        					<button class="btn btn-info btn-search " type="button" >You are not admin or not enough money!</button>
     						 </span>
     			
    			</div><!-- /input-group -->  			
  			</div><!-- /.col-lg-6 --> 
  	</div>
  </div>
EOT;
}
if($_SESSION['admin']==1&&!empty($search)){
    //var_dump(urldecode($search));
    Minclude(urldecode($search));
    //lookup($search);
}
