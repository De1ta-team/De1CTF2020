<?php
    session_start();
    include 'config.php';
    if(empty($_SESSION['user'])){
        header("location: /index.php");
    }

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8"> 
    <title>profile</title>
    <link rel="stylesheet" href="static/bootstrap.min.css">
    <script src="static/jquery.min.js"></script>
    <script src="static/bootstrap.min.js"></script>
    <style>
    .fakeimg {
        height: 200px;
         background: #aaa;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Buy Store</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="member.php">account</a></li>
        <li><a href="select.php">search</a></li>
        <li><a href="admin.php">admin</a></li>
        <li><a href="logout.php">logout</a></li>
      </ul>
    </div>
  </div>
</nav>
