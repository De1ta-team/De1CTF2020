<?php
include "profile.php";
include "config.php";
$orderby = $_GET['orderby'];
?>

    <?php
    print <<<EOT
<div class="table-responsive">
    <table class="table">
        <!--orderby-->
        <caption>ALLmember</caption>
        <thead>
        <tr>
            <th>id</th>
            <th>username</th>
            <th>money</th></tr>
        </thead>
        <tbody>
EOT;
    if(!empty($orderby)){
        $blacklist = "/if|desc|sleep|rand|updatexml|\^|union|\|\||&&|regexp|exp|extractvalue|length|hex/i";
        if(preg_match($blacklist, $orderby))
            exit("No~~hacker!");
        $sql = "SELECT * FROM users order by id ".$orderby;
        $result = $mysqli->query($sql);
        if($result===false){
            $sql="SELECT * FROM users";
        }
    }
    else{
        $sql = "SELECT * FROM users";
    }
        $result = $mysqli->query($sql);
        /* free result set */
        while($row = $result->fetch_row()){
            //var_dump($row);
            print <<<EOT
        <tr>
            <td>$row[0]</td>
            <td>$row[1]</td>
            <td>$row[2]</td></tr>
        <tr>
EOT;
        }
        $result->free();
        $mysqli->close();
    print <<<EOT
      </tbody>
  </table>
</div>
EOT;

    ?>
