/usr/bin/timeout 90 python server.py
