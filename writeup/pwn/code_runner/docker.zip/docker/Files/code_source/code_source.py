fmt=['''
int func_{func_idx}(uint8_t *s)
{brackets_0}
if(s[{arg_0}]=={arg_4})
	if(s[{arg_1}]=={arg_5})
		if(s[{arg_2}]==s[{arg_0}]*s[{arg_0}]%256)
			if(s[{arg_3}]==(uint8_t)(s[{arg_1}]*s[{arg_1}]+s[{arg_2}]*s[{arg_2}]-s[{arg_0}]*s[{arg_0}]))
				return func_{func_next}(s+4);
return 0;
{brackets_1}
''',
'''
int func_{func_idx}(uint8_t *s)
{brackets_0}
if((s[{arg_0}] ^ s[{arg_1}] )== {arg_4})
	if(s[{arg_1}]=={arg_5})
		if(s[{arg_2}]==(uint8_t)(2*(s[{arg_0}]^s[{arg_1}])+(s[{arg_0}]^s[{arg_0}])-(s[{arg_1}]^s[{arg_1}])))
			if(s[{arg_3}]==(uint8_t)(s[{arg_0}]^s[{arg_1}]^s[{arg_2}]))
				return func_{func_next}(s+4);
return 0;
{brackets_1}
''',
'''
int func_{func_idx}(uint8_t *s)
{brackets_0}
if(s[{arg_0}]==s[{arg_2}])
    if(s[{arg_3}]==s[{arg_1}])
        if(s[{arg_3}]=={arg_4})
            if(s[{arg_2}]=={arg_5})
                return func_{func_next}(s+4);
return 0;
{brackets_1}
''',
'''
int func_{func_idx}(uint8_t *s)
{brackets_0}
if( abs(s[{arg_0}]*s[{arg_0}]-s[{arg_3}]*s[{arg_3}]) {m1} abs(s[{arg_1}]*s[{arg_1}]-s[{arg_2}]*s[{arg_2}]) )
if( abs(s[{arg_1}]*s[{arg_1}]-s[{arg_0}]*s[{arg_0}]) {m2} abs(s[{arg_2}]*s[{arg_2}]-s[{arg_3}]*s[{arg_3}]) )
                return func_{func_next}(s+4);
return 0;
{brackets_1}
''',
'''
int func_{func_idx}(uint8_t *s)
{brackets_0}
if((uint32_t)(s[{arg_0}]+s[{arg_1}]+s[{arg_2}]) == {cal_0} )
    if((uint32_t)(s[{arg_1}]+s[{arg_2}]+s[{arg_3}]) == {cal_1})
        if((uint32_t)(s[{arg_2}]+s[{arg_3}]+s[{arg_0}]) == {cal_2})
            if((uint32_t)(s[{arg_3}]+s[{arg_0}]+s[{arg_1}]) == {cal_3})
                return func_{func_next}(s+4);
return 0;
{brackets_1}
''',
'''
int func_{func_idx}(uint8_t *s)
{brackets_0}
if(s[{arg_0}]+s[{arg_1}] != {arg_4} )
    if(s[{arg_1}]+s[{arg_2}] != {arg_5})
        if(s[{arg_2}]+s[{arg_3}] != {arg_6})
            if({arg_5}+{arg_6} != {arg_7})
                return func_{func_next}(s+4);
return 0;
{brackets_1}
''',
]
source_head='''
#include <stdint.h>
#include <ctype.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/time.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/prctl.h>
#include <linux/filter.h>
#include <string.h>
unsigned int rnd=0;
int func_16(uint8_t *s)
{
	return 0xc001babe;
}

'''
source_tail='''
int filter(uint8_t *s)
{
	return func_0(s);
}
int logo()
{
	char* buf=malloc(299);
	int i=open("./logo",0,0);
	read(i,buf,299);
	printf("%s\\n",buf);
	free(buf);
	buf=0;
}
void init()
{
	logo();
	setvbuf(stdin,0,2,0);
	setvbuf(stdout,0,2,0);
	setvbuf(stderr,0,2,0);
}

int check()
{
	uint8_t buf[0x100];
	memset(buf,0,0x100);
	puts("Faster > ");
	read(0,buf,0x100);
	return filter(buf);
	
}
void doc(unsigned long long int c)
{
    char buf[0x69]={0};
	char name[0x8]={0};
	printf("Name\\n> ");
	read(0,name,8);
	for(int i=0;i<strlen(name);i++)
	{
		if(!isalpha(name[i]))
		{
			printf("Alpha only\\n");
			_exit(0);
		}
	}
        FILE *fp=fopen("/Time","a+");
		memset(buf,0,sizeof(buf));
        snprintf(buf,sizeof(buf),"%llu:%s\\n",c,name);
        fputs(buf,fp);
        fclose(fp);
}
int main()
{
	struct timeval t1,t2;
	gettimeofday(&t1,NULL);
	void (*p)();
	char buf[0x100]={0};
	p=(void (*))buf;
	init();
	if(check())
	{
	gettimeofday(&t2,NULL);
	unsigned int tmp=t2.tv_sec-t1.tv_sec;
	long long int t=tmp*1000000+t2.tv_usec-t1.tv_usec;
	printf("======== %lld.%llds ========\\n",t/1000000,t%1000000);
	doc(t);
	puts("Your time comes.\\n> ");
	unsigned long long int r=t/100000;
    if(r<13)
            read(0,buf,(13-r)*4);
    p();
	}
}

'''