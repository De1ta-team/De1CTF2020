import base64
import subprocess
import sys
import time
def dump_binary(name):
	print("Binary Dump:")
	print("="*15)
	tmp=open(name,'r')
	data=base64.b64encode(tmp.read())
	print(data)
	sys.stdout.flush()
	print("="*15)
	tmp.close()
def panel():
	#show the fastest runner
	pass
def do_dump(name):
	# Arguments
	name=str(name)
	ret=subprocess.Popen(("gzip -c /tmp/"+name).split(" "),stdout=subprocess.PIPE)
	ret.wait()
	tmp=open("/compressed/"+name+".gz","w+")
	tmp.write(ret.stdout.read())
	tmp.close()
	dump_binary("/compressed/"+name+".gz")
	print("Rank(Refresh Every Min)")
	f=open("./Rank","r")
	print("="*15)
	time=[]
	name=[]
	for _ in range(3):
		time.append(f.readline()[:-1])
		name.append(f.readline()[:-1])
	print("1st. "+name[0]+"("+time[0]+")")
	print("2ed. "+name[1]+"("+time[1]+")")
	print("3th. "+name[2]+"("+time[2]+")")
	f.close()
	sys.stdout.flush()
if __name__ == '__main__':
	do_dump(930693941)#test