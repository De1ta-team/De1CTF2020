import subprocess
import time
import os
def do_clear():
    ret=os.system("rm -rf /home/ctf/tmp/*")
    ret=os.system("rm -rf /compressed/*")
    ret=os.system("rm -rf /tmp/*")
def ps_killer():
    ret=os.system("ps -ef | grep 'python /server.py' | awk '{print $2}' | xargs kill -9")
def do_rank():
    f1=open("/home/ctf/Time",'r')
    f2=open("/Rank",'r')
    d1=f1.read().strip().split("\n")
    if(d1[0]==''):
        return
    d2=f2.read().strip().split("\n")
    f1.close()
    f2.close()
    ##########
    t2=[]
    if(len(d2)!=0):
        for x in range(0,len(d2)/2,2):
            t2.append((int(d2[x]),d2[x+1]))
    #########
    
    tmp=[]
    if(str(d1)!=''):
        for x in range(len(d1)):
            if(d1[x]!=""):
                tmp.append(d1[x].split(":"))
    t1=[]
    for x in range(len(tmp)):
        t1.append((int(tmp[x][0]),tmp[x][1]))
    t= t1+t2
    t.sort()
    f=open("/Rank","w")
    tmp=3
    if len(t) <3:
        tmp=len(t)
    for x in range(tmp):
        f.write(str(t[x][0])+"\n")
        f.write(t[x][1]+"\n")
    f.close()
    os.system('echo ""> /home/ctf/Time')
while(1):
    ps_killer()
    do_clear()
    do_rank()
    time.sleep(600)
