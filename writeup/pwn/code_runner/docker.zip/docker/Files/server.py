import code_source.code_source as source
import code_source.dump as dp
import subprocess
import time
import sys
import hashlib
# source_code init 
def judge(idx,tmp):
	a=abs(tmp[idx]*tmp[idx]-tmp[(idx-1)%4]*tmp[(idx-1)%4])
	b=abs(tmp[(idx+1)%4]*tmp[(idx+1)%4]-tmp[(idx+2)%4]*tmp[(idx+2)%4])
	if a < b:
		return "<"
	else:
		return ">="
def u32(s):
	return ord(s[0])+ord(s[1])*0x100+ord(s[2])*0x10000+ord(s[3])*0x1000000
def get_rnd():
	return ord(f.read(1))
def creater(seed):
	name="/tmp/{}.c".format(seed)
	code=open(name,'w+')
	# compile part
	code.write(source.source_head)
	l=len(source.fmt)
	for x in range(0x10):
		cal=[]
		s_idx=get_rnd()%4
		for _ in range(4):
			cal.append(get_rnd())
		tum_sum=sum(cal)
		tmp=source.fmt[get_rnd()%l].format(func_idx=0xf-x,arg_0=s_idx,arg_1=(s_idx+1)%4,arg_2=(s_idx+2)%4,arg_3=(s_idx+3)%4,arg_4=get_rnd(),arg_5=get_rnd(),arg_6=get_rnd(),arg_7=get_rnd(),brackets_0="{",brackets_1="}",func_next=0x10-x,cal_0=tum_sum-cal[0],cal_1=tum_sum-cal[1],cal_2=tum_sum-cal[2],cal_3=tum_sum-cal[3],m1=judge(s_idx,cal),m2=judge((s_idx+1)%4,cal))
		code.write(tmp)
	code.write(source.source_tail)
	code.close()
	cmd="mipsel-linux-gnu-gcc {scode} -o /tmp/{binary} -s".format(scode=name,binary=seed)
	ret=subprocess.Popen(cmd.split(" "))
	ret.wait()
	f.close()
def runner(seed):
    ret=subprocess.Popen("mv /tmp/{} /home/ctf/tmp".format(seed).split(" "))
    ret.wait()
    ret=subprocess.Popen("/usr/sbin/chroot --userspec=1000:1000 /home/ctf /usr/bin/timeout -s 9 60 qemu-mipsel -L /usr/mipsel-linux-gnu /tmp/{}".format(seed).split(" "))
    ret.wait()
    exit()
def do_main(seed):
	creater(seed)# creater binary 
	dp.do_dump(seed)# leak the binary.gz
	sys.stdout.flush()
	runner(seed)#run binary
def pow(s):
	res=hashlib.sha256(s).hexdigest()
	print "=========Pow========"
	print 'hashlib.sha256(s).hexdigest() == "%s"' % res
	print "len(s) == 3"
	print '>'
	sys.stdout.flush()
	input = raw_input()
	if input != s:
		exit(0x1337)
if __name__ == "__main__":
	f=open("/dev/urandom",'r')
	pow(f.read(3))
	seed=u32(f.read(4))
	do_main(seed)
	f.close()
