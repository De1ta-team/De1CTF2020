该题目是用xinted启动的，xinted的配置在ctf.xinetd
docker的配置在DockerFile和docker-compose.yml中
启动docker使用

docker-compose up或者docker-compose up -d